<?php
session_start();
$con = mysqli_connect("localhost","root","","registration");

$Name = $_POST['Name'];
$Email = $_POST['Email'];

$que = mysqli_query($con,"select * from register where Name='$Name'");
while($ans=mysqli_fetch_array($que))
{
	$a=$ans['Name'];
	$b=$ans['Email'];
    
}
if($Name == $a and $Email == $b)
{
	$_SESSION['Name']=$Name;
	header('location:index.html');
}
else
{
	header('location:login.html');
}


?>