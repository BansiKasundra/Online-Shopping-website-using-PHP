<?php
session_start();
$con = mysqli_connect("localhost","root","","registration");


$Name= $_POST['Name'];
$Email= $_POST['Email'];
$Password= $_POST['Password'];

echo $Name;

$que = mysqli_query($con,"insert into register (Name,Email,Password) values ('$Name','$Email','$Password')");

if($que)
	// echo"hello";
	header('location:login-form.php');
// else
//  echo "error";
// header('location:login.html');

// $que = mysqli_query($con,"select * from register where Name='$Name'");
// while($ans=mysqli_fetch_array($que))
// {
// 	$a=$ans['Name'];
// 	$b=$ans['Email'];
    
// }
// if($Name == $a and $Email == $b)
// {
// 	echo "success";
// 	$_SESSION['Name']=$Name;
// 	header('location:login.php');
// }
// else
// {
// 	echo "fail";
// 	header('location:login.html');
// }
?>