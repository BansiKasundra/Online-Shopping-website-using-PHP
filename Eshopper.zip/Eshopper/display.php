<?php
session_start();
if(isset($_SESSION['Name']))
{
	$con = mysqli_connect("localhost","root","","registration");
?>
<html>
<body>
<div>
<form action="logout.php" method="POST">
<?php
echo "Welcome"." ".$_SESSION['Name'];
?>
<br>
<input type="submit" name="submit" value="Logout">
</form>
</div>
<center>
<font size="20"> Registration Details </font><br>
<table border="1">
<tr>
<th>Name</th>
<th>Email</th>
<th>Update</th>
<th>Remove</th>
</tr>
<?php
$que = mysqli_query($con,"select * from register");
while($ans = mysqli_fetch_array($que))
{ ?>
<tr>
<td><?php echo $ans['Name']; ?></td>
<td><?php echo $ans['Email']; ?></td>
<td><a href="update.php?id=<?php echo $ans['En']; ?>">edit</a></td>
<td><a href="delete.php?id=<?php echo $ans['En']; ?>">delete</a></td>
</tr>
<?php
}
?>
</table>
</body>
</html>
<?php
}
else
{
	header('location:login.html');
}
?>
